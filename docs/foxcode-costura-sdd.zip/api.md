# API / Contracts

## Principio

Las operaciones de negocio críticas deben ejecutarse con lógica centralizada.

## Contratos principales

### calculateQuote

Input conceptual:

```json
{
  "clientId": "uuid",
  "garmentType": "dress",
  "services": [
    {
      "serviceId": "uuid",
      "quantity": 1
    }
  ],
  "materials": [
    {
      "materialId": "uuid",
      "quantity": 3
    }
  ],
  "complexity": "medium",
  "urgency": "normal"
}
```

Output conceptual:

```json
{
  "materials": 123,
  "labor": 80,
  "complexity": 16,
  "urgency": 0,
  "margin": 43.8,
  "suggestedPrice": 262.8
}
```

Los nombres exactos y fórmula definitiva deben fijarse en la implementación de SPEC-001.

## Operaciones
- createQuote
- calculateQuote
- updateMaterialPrice
- acceptQuote
- convertQuoteToWorkOrder
- updateWorkOrder
- completeWorkOrder

## Regla
No confiar en valores monetarios enviados por el cliente para operaciones definitivas. El servidor debe resolver precios y configuración autorizados.
