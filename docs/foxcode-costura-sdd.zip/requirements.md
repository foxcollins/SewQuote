# Requirements

## Requisitos funcionales

### REQ-001 Autenticación
El sistema debe permitir registro, login, logout y recuperación de acceso.

### REQ-002 Negocio/Tenant
Cada usuario debe pertenecer a un tenant/negocio. Los datos de un tenant no deben ser visibles para otro.

### REQ-003 Clientes
Crear, editar, consultar y archivar clientes. Asociar presupuestos y trabajos.

### REQ-004 Prendas
Una cotización debe poder identificar la prenda: vestido, pantalón, camisa, blusa, falda, chaqueta, traje, uniforme u otra.

### REQ-005 Servicios
El usuario puede crear y modificar servicios con nombre, categoría, precio base opcional, tiempo estimado, unidad y estado.

### REQ-006 Materiales
El usuario puede crear materiales con nombre, categoría y unidad.

### REQ-007 Historial de precios
Cada cambio de precio de material debe crear un registro histórico con fecha de vigencia. Nunca se debe sobrescribir el historial.

### REQ-008 Presupuestos
El usuario puede crear un presupuesto con cliente, prenda, servicios, materiales, cantidades, complejidad, urgencia, notas y validez.

### REQ-009 Cálculo
El sistema debe producir un desglose verificable del precio sugerido.

### REQ-010 Congelación
Una vez guardado un presupuesto, los precios de materiales utilizados deben quedar como snapshot.

### REQ-011 Override
El profesional puede modificar el precio sugerido y registrar precio final y motivo opcional.

### REQ-012 Estados de presupuesto
Draft, sent, accepted, rejected, expired, cancelled.

### REQ-013 Orden de trabajo
Un presupuesto aceptado puede convertirse en orden de trabajo.

### REQ-014 Estados de trabajo
accepted, waiting_garment, in_production, fitting, adjustments, ready, delivered, cancelled.

### REQ-015 Resultado real
Registrar tiempo real, materiales realmente utilizados, precio final y observaciones.

### REQ-016 Historial
Los trabajos finalizados deben quedar disponibles para análisis futuro.

### REQ-017 PWA
La interfaz debe ser responsive e instalable como PWA.

### REQ-018 Configuración
Configurar moneda, idioma, zona horaria, tarifa horaria, margen, desperdicio, factores de complejidad y recargos de urgencia.

## Requisitos no funcionales

### NFR-001 Seguridad
Usar Supabase Auth + RLS y validación server-side.

### NFR-002 Consistencia
El mismo input debe producir el mismo resultado de cálculo.

### NFR-003 Auditabilidad
El sistema debe poder explicar cómo se obtuvo un precio.

### NFR-004 Internacionalización
No hardcodear BRL, formatos de fecha ni textos del dominio.

### NFR-005 Escalabilidad
La arquitectura debe permitir evolucionar de un MVP a SaaS multi-tenant sin rediseñar el dominio central.

### NFR-006 Usabilidad
Crear un presupuesto debe requerir el mínimo de pasos posible. Los campos avanzados deben poder ser opcionales.
