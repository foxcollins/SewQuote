# Testing

## Unit tests

### Pricing
Probar:
- material único;
- múltiples materiales;
- cantidades;
- desperdicio;
- mano de obra;
- complejidad;
- urgencia;
- margen;
- redondeo;
- override.

### Historical pricing
Caso obligatorio:

```text
Material = Satén
Precio A = 41
Quote A → snapshot 41

Precio actual cambia a 45

Quote A debe continuar mostrando 41.
Nuevo Quote B debe utilizar 45.
```

## Integration tests
- Auth + tenant isolation.
- Crear cliente.
- Crear material.
- Cambiar precio.
- Crear presupuesto.
- Aceptar presupuesto.
- Convertir a trabajo.
- Registrar resultado.

## Security tests
Intentar:
- consultar cliente de otro tenant;
- modificar material de otro tenant;
- modificar quote de otro tenant;
- acceder a archivos privados ajenos.

Todos deben fallar.

## E2E
Flujo mínimo:

```text
Registro
→ crear configuración
→ crear cliente
→ crear servicio
→ crear material
→ registrar precio
→ crear presupuesto
→ revisar cálculo
→ aceptar
→ convertir en trabajo
→ finalizar
```

## Acceptance
Cada requisito REQ debe tener al menos un criterio de aceptación verificable antes de considerar el MVP terminado.
