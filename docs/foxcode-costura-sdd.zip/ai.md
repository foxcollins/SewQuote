# AI Architecture

## Estado MVP
La IA no es dependencia del MVP.

## Principio
```text
IA = interpretación/asistencia
Código = cálculo/reglas
Profesional = decisión final
```

## V1 — Natural Language Intake

Ejemplo:

> "Necesito ajustar la cintura y acortar 8 cm este vestido de satén con forro."

La IA transforma la solicitud en datos estructurados.

```json
{
  "garment": "vestido",
  "material": "satén",
  "services": [
    "ajuste_cintura",
    "reducir_largo"
  ],
  "attributes": {
    "lining": true,
    "length_reduction_cm": 8
  }
}
```

Después:

```text
Structured Input
→ Pricing Engine
→ Calculation
```

## Restricciones
La IA no puede:
- inventar precios;
- aprobar presupuestos;
- cambiar la tarifa horaria;
- modificar el margen;
- confirmar órdenes;
- saltarse permisos.

## Futuro
- recomendación basada en trabajos similares;
- estimación de tiempo;
- detección de subprecio;
- análisis de fotos;
- extracción de servicios desde conversación.

## Human-in-the-loop
El profesional debe poder editar todos los datos inferidos antes del cálculo definitivo.
