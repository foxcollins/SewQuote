# Security

## Auth
Supabase Auth.

## Authorization
Row Level Security obligatoria para tablas multi-tenant.

## Tenant isolation
Toda consulta y mutación debe estar limitada al tenant autenticado.

## Server-side validation
Validar:
- IDs pertenecientes al tenant.
- cantidades positivas.
- precios válidos.
- estados válidos.
- transiciones válidas.
- permisos.

## Storage
Fotos y documentos deben utilizar buckets privados cuando contengan información del cliente.

## Datos personales
Los datos de clientes deben tratarse como información privada y solo estar disponibles al tenant correspondiente.

## IA
No enviar información innecesaria a proveedores de IA. Cuando sea posible, minimizar PII antes de procesarla.

## Prompt injection
Si posteriormente se incorpora IA, el contenido del cliente/prenda debe considerarse input no confiable. Nunca debe poder ejecutar instrucciones de sistema, modificar precios directamente o saltarse validaciones.

## Auditoría
Registrar cambios relevantes:
- cambio de precio de material;
- cambio de precio final;
- aceptación/rechazo;
- modificación de orden de trabajo.
