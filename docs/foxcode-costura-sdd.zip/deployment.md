# Deployment

## MVP

### Frontend
Vercel.

### Backend
Supabase.

### Base de datos
PostgreSQL administrado por Supabase.

### Storage
Supabase Storage.

## Entornos
- local
- staging
- production

Si el presupuesto inicial es muy reducido, staging puede simplificarse durante el prototipo, pero producción debe estar aislada.

## Variables
Nunca almacenar secretos en Git.

Variables sensibles:
- Supabase URL.
- Supabase anon key.
- Service role key únicamente server-side.
- futuras API keys de IA.

## CI/CD
GitHub + despliegue automático.

## Observabilidad
Inicial:
- logs;
- errores frontend;
- errores server-side;
- métricas básicas de uso.

Posteriormente:
- error tracking;
- tracing;
- métricas de pricing;
- costos de IA.
