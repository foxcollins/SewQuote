# Architecture

## Arquitectura propuesta

```mermaid
flowchart TD
    A[PWA Next.js] --> B[Supabase Auth]
    A --> C[Supabase PostgreSQL]
    A --> D[Supabase Storage]
    A --> E[Server Actions / Edge Functions]

    E --> F[Pricing Engine]
    F --> G[Services]
    F --> H[Materials]
    F --> I[Material Price History]
    F --> J[Tenant Settings]
    F --> K[Historical Work Data]

    A -. future .-> L[AI Assistant]
    L --> E
```

## Frontend
- Next.js.
- TypeScript.
- Tailwind CSS.
- PWA.
- Formularios con validación.
- UI mobile-first.

## Backend
Supabase será la plataforma inicial:
- PostgreSQL.
- Auth.
- Storage.
- RLS.
- Edge Functions cuando se requiera ejecución server-side.

## Dominio
El pricing engine debe ser independiente de la UI.

Conceptualmente:

```text
QuoteInput
   ↓
Validation
   ↓
Material resolution
   ↓
Labor calculation
   ↓
Complexity
   ↓
Urgency
   ↓
Additional costs
   ↓
Margin
   ↓
QuoteCalculation
```

## Principio arquitectónico
La UI no debe contener la lógica definitiva de precios.

## Escalabilidad
Inicialmente no se necesita microservicios. Un monolito modular sobre Next.js + Supabase es suficiente.

Separar desde el código los módulos:
- auth
- tenants
- clients
- catalog
- pricing
- quotes
- work-orders
- analytics
