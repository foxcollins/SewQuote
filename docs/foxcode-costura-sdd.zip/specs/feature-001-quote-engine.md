# SPEC-001 — Quote Engine

## Objetivo
Calcular un precio sugerido de forma reproducible y explicable.

## Input
- servicios;
- cantidades;
- materiales;
- cantidades;
- precios vigentes;
- desperdicio;
- tiempo estimado;
- tarifa horaria;
- complejidad;
- urgencia;
- costos adicionales;
- margen.

## Fórmula base propuesta

```text
material_cost =
    Σ(quantity × unit_price × (1 + waste))

labor_cost =
    estimated_minutes / 60 × hourly_rate

base_cost =
    material_cost + labor_cost + other_costs

complexity_adjustment =
    base_cost × complexity_factor

urgency_adjustment =
    base_cost × urgency_factor

cost_before_margin =
    base_cost
    + complexity_adjustment
    + urgency_adjustment

suggested_price =
    cost_before_margin × (1 + margin)
```

## DECISIÓN PENDIENTE
La fórmula exacta de margen, complejidad y urgencia debe validarse con usuarios reales antes de congelar SPEC-001.

La fórmula anterior es una DECISIÓN PROPUESTA para el MVP, no un requisito confirmado.

## Complejidad propuesta

```text
low       = 0%
medium    = configurable
high      = configurable
very_high = configurable
```

## Urgencia propuesta

```text
normal      = 0%
urgent      = configurable
very_urgent = configurable
```

## Reglas
1. Los porcentajes deben ser configurables por tenant.
2. El cálculo debe devolver desglose.
3. El usuario puede modificar el precio final.
4. El sistema debe conservar el sugerido.
5. Los materiales deben utilizar el precio vigente en el momento del cálculo.
6. Al guardar el presupuesto, los precios quedan congelados.

## Acceptance Criteria

### AC-001
Dado un material con precio conocido, la cantidad multiplicada por su precio produce el costo correspondiente.

### AC-002
Si cambia el precio del material después de guardar un presupuesto, el presupuesto existente no cambia.

### AC-003
Un nuevo presupuesto utiliza el nuevo precio vigente.

### AC-004
El sistema muestra el desglose del cálculo.

### AC-005
El usuario puede modificar el precio sugerido.

### AC-006
El precio final no modifica retroactivamente el cálculo original.

### AC-007
El mismo input y configuración produce el mismo resultado.

### AC-008
Un usuario no puede calcular usando materiales pertenecientes a otro tenant.
