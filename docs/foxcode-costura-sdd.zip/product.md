# Product

## Problema
Profesionales de costura, reparación y confección necesitan calcular presupuestos considerando materiales, mano de obra, complejidad, urgencia y margen. Los precios de materiales cambian con el tiempo y los trabajos anteriores contienen información útil que normalmente no se aprovecha.

## Usuario objetivo
- Costureras/modistas independientes.
- Sastres.
- Pequeños ateliers.
- Profesionales de ajustes y reparación de ropa.

## Propuesta de valor
Calcular presupuestos consistentes basados en costos reales, tiempo de trabajo y experiencia histórica, sin convertir el proceso en una herramienta administrativa compleja.

## Producto
PWA SaaS para:
1. gestionar clientes;
2. gestionar servicios;
3. gestionar materiales y sus precios históricos;
4. calcular presupuestos;
5. convertir presupuestos aceptados en trabajos;
6. registrar resultados reales;
7. utilizar posteriormente ese histórico para recomendaciones.

## Diferenciación propuesta
El foco inicial no será competir como ERP de atelier. El núcleo será un motor de presupuestación sencillo y progresivamente inteligente.

## MVP
Incluye:
- Auth.
- Perfil/negocio.
- Clientes.
- Servicios.
- Materiales.
- Historial de precios.
- Configuración de mano de obra y margen.
- Motor de presupuestos.
- Presupuestos.
- Conversión a orden de trabajo.
- Registro básico del resultado.

## V1
- WhatsApp.
- PDF.
- Link público de presupuesto.
- Medidas.
- Fotos.
- Agenda.
- Pagos.
- Rentabilidad.
- Historial avanzado.

## V2
- Asistente IA.
- Interpretación de solicitudes.
- Recomendación basada en históricos.
- Predicción de tiempo.
- Detección de posible subprecio.
- Análisis de imágenes como asistencia.

## Fuera del MVP
- Contabilidad completa.
- Facturación electrónica.
- Nómina.
- Inventario avanzado.
- Marketplace.
- E-commerce.
- App nativa.
- Automatización avanzada de WhatsApp.
- Computer vision como requisito.

## Internacionalización
Desde el inicio:
- Español.
- Portugués brasileño.
- País configurable.
- Moneda configurable.
- Zona horaria configurable.
No asumir Brasil/BRL como regla del dominio.
