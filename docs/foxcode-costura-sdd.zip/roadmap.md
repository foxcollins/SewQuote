# Roadmap

## Fase 0 — Discovery / Specification
- Validar fórmula de precios.
- Validar UX con profesionales reales.
- Definir catálogo inicial.
- Confirmar modelo de negocio.
- Completar SDD.

## MVP
- Auth.
- Tenant.
- Clientes.
- Servicios.
- Materiales.
- Historial de precios.
- Configuración.
- Motor de precios.
- Presupuestos.
- Orden de trabajo básica.
- PWA.

## V1
- PDF.
- WhatsApp.
- Link público.
- Medidas.
- Fotos.
- Agenda.
- Pagos.
- Dashboard financiero.
- Rentabilidad.

## V2
- IA.
- Recomendaciones históricas.
- Predicción de tiempo.
- Detección de subprecio.
- Análisis de imagen.

## No construir inicialmente
- ERP completo.
- Contabilidad.
- Nómina.
- Inventario avanzado.
- Marketplace.
- App nativa.
- Automatizaciones complejas.

## Métricas de validación
Antes de ampliar producto medir:
- presupuestos creados por usuario;
- tiempo para crear presupuesto;
- porcentaje de presupuestos aceptados;
- trabajos registrados;
- frecuencia de reutilización;
- diferencia entre precio sugerido y precio final;
- retención.
