# Data Model

## Principales entidades

### tenants
- id
- name
- country
- currency
- timezone
- locale
- created_at

### profiles
- id
- tenant_id
- name
- role
- created_at

### clients
- id
- tenant_id
- name
- phone
- whatsapp
- email
- notes
- created_at
- updated_at

### garments
- id
- tenant_id
- client_id
- type
- description
- notes
- created_at

### services
- id
- tenant_id
- name
- category
- base_price
- estimated_minutes
- unit
- active
- created_at
- updated_at

### materials
- id
- tenant_id
- name
- category
- unit
- active
- created_at

### material_prices
- id
- material_id
- unit_price
- currency
- valid_from
- created_at

### quotes
- id
- tenant_id
- client_id
- garment_id
- status
- subtotal_materials
- subtotal_labor
- subtotal_other
- complexity_amount
- urgency_amount
- margin_amount
- suggested_price
- final_price
- override_reason
- valid_until
- notes
- created_at
- updated_at

### quote_items
- id
- quote_id
- service_id
- description_snapshot
- quantity
- estimated_minutes
- unit_price
- total

### quote_materials
- id
- quote_id
- material_id
- material_name_snapshot
- quantity
- unit_snapshot
- unit_price_snapshot
- waste_percent
- total

### work_orders
- id
- tenant_id
- quote_id
- status
- started_at
- completed_at
- actual_minutes
- actual_price
- notes

### work_materials
- id
- work_order_id
- material_id
- quantity
- unit_price
- total

### measurements
- id
- tenant_id
- client_id
- garment_id
- measurement_type
- value
- unit
- recorded_at

## Regla crítica de snapshots

Los presupuestos deben guardar:
- nombre del material;
- unidad;
- precio unitario;
- cantidad;
- desperdicio;
- total.

No depender exclusivamente de una consulta futura a `material_prices`.

Esto garantiza reproducibilidad histórica.

## Multi-tenancy
Todas las entidades de negocio deben incluir `tenant_id` directa o indirectamente y estar protegidas por RLS.
