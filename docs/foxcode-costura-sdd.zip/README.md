# Sistema Inteligente de Presupuestos para Confección — SDD

## Estado
Draft inicial de especificación.

## Fuente de verdad
Estos documentos definen el alcance, reglas y arquitectura del MVP.

## Documentos
- product.md
- requirements.md
- architecture.md
- data-model.md
- api.md
- security.md
- ai.md
- testing.md
- deployment.md
- roadmap.md
- specs/feature-001-quote-engine.md
- decisions/ADR-001-pricing-engine.md

## Principio
El motor determinístico calcula. La IA interpreta y asiste. El profesional conserva la decisión final.
